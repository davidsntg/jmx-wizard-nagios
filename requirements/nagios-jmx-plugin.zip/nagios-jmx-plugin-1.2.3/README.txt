Copyright 2009 Felix Roethenbacher

*******************************************************************************
*                                                                             *
* Nagios JMX Plugin                                                           *
*                                                                             *
*******************************************************************************

Version 1.2.3


Copy

  - check_jmx
  - check_jmx.jar
  
to your Nagios plugin directory.

For a couple of sample command definitions copy

  - jmx.cfg
  
to your Nagios plugin configuration directory. 


For further information see http://snippets.syabru.ch/nagios-jmx-plugin/index.html